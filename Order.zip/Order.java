import java.util.*;
import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;

public class Order{

   //public String maxLength(String
   public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
      Scanner fileInput = null;
      System.out.println("Enter the name of the word lists text file:");
      String fileName = sc.nextLine();
      try{
         fileInput = new Scanner(new File(fileName));
      }catch(FileNotFoundException e){
         System.out.println("File not found.");
      }finally{
         sc.close();
      }
      
      while(fileInput.hasNextLine()){
         String line = fileInput.nextLine();
//          String[] words = line.split(" ");
//          int longest = 1;
//          int tempMax = 1;
//          int multiSol = 1;
//          for (int i = 0; i<words.length - 1; i++){
//             if(words[i].compareTo(words[i+1])<0){
//                longest++;
//             }else if(words[i].compareTo(words[i+1])>0){
//                longest = 1;
//             }
//             if(tempMax<longest){
//                tempMax = longest;
//             }else if(tempMax== longest){
//                multiSol++;
//             }
//          }
//          if(multiSol>1){
//             System.out.println("Multiple solutions length " + tempMax);
//          }else{
//             System.out.println("Longest length " + tempMax);
//          }
         int multiSol = 0;
         StringTokenizer st = new StringTokenizer(line);
         while(st.hasMoreTokens()){
            int longest = 1;
            int temp = 1;
            String first = st.nextToken();
            while(st.hasMoreTokens()){
               String next = st.nextToken();
               
               if(first.compareTo(next)<0){
                  longest++;
               }else if (first.compareTo(next)>0){
                  longest = 1;
               }
               
               first = next;
               
               if(temp<longest){
                  temp = longest;
                  multiSol = 0;
               }
               else if (temp == longest)
                  multiSol++;
               
            }if(multiSol>0){
               System.out.println("Multiple solutions length " + temp + ".");
            }else{
               System.out.println("Longest is " + temp + ".");
            }
            
         }
      }
      System.out.println("Done");
   }
}